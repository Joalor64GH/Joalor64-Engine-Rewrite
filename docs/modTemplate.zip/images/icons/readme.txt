Put your custom character icons here!
The image resolution must be one of these:
150x150 (1 Icon)
300x150 (2 Icons)
450x150 (3 Icons)
750x150 (5 Icons)