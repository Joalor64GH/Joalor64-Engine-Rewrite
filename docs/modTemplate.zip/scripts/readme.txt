Add scripts here!
The following formats are allowed:
.lua
.hscript
.hx

If you've put your script(s) inside a modpack, the script(s) will be running. As long as the modpack is loaded.

(LUA ONLY FOR NOW)
ABOUT DOCUMENTATION:
You can add documentation and intellisense to your code by including ---@module 'header' at the top of your script, this will import all the documentation.