Redirect yourself to here for instructions:
https://github.com/Verwex/Funkin-Mic-d-Up-SC/tree/stable/example_mods