You can either edit files or add entirely new ones here.

ABOUT EDITING:
It doesn't matter if you want to edit something in assets/images/,
because if you put the edited files in mods/images/, it will automatically be handled by the engine.