okay okay
so basically, you just need two main text files

'languagesList' - simply your list of languages (de, en, es, fr, it, and so on...)
'languagesData' - this is so the languages can be pushed into LanguageState 

languagesData formatting example:
Deustch:de
English:en
etc...

then you need a json file called 'languageData.json'
this is just self-explanatory, it's the data for your language

it should be located in 'mods/locales/(your language)/languageData.json'

extra stuff:
you can add a flag for your language in assets/images/flags/(your language)
you can add localized images/sounds

and that's all there is to it!
i mean, if you actually want to use it