Add your custom event's .txt and .lua file here!

The .txt file is the event's description in Chart Editor.